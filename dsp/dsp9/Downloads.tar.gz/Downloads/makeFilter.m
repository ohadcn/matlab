% function [Hd] = makeFilter(f,Fs,deltaF,harmonicsNumber)
% N = 5000;
% winType = 'blackman';
% 
% % frequency bands to filter
% w = zeros(2*harmonicsNumber,1);
% % filter main frequency and its harmonics
% for i=1:harmonicsNumber
%     
%     w(2*i-1,1) = i*(f/(Fs/2)) - deltaF;
%     w(2*i,1) = i*(f/(Fs/2)) + deltaF;
% end
% % b parameter of filter
% 
% Hd = fir1(N,w(:,1),'DC-0',feval(winType,N+1));  
% 
% 
% end

%this file was written by Ohad Cohen & Aviad Eden for ex. 9 in DSP
function [Hd] = makeFilter(f,fs,deltaF,harmonicsNumber,N)
%makeFilter This function makes a multi-band FIR filter.
    if (nargin<5)
        N = 5000;
    end
    winType = 'hamming';
    freq=2*f/fs;
    h=1:harmonicsNumber;
    w=sort([(h*freq-deltaF),(h*freq+deltaF)]);
    Hd = fir1(N,w,'DC-0',feval(winType,N+1));
end