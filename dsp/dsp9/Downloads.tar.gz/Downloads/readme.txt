to use the spectram images, you must first find the right image: the image
in which you can see clear the lines of the relevant frequencies, and you
can see clearly the difference for difrent times.
when you find the right image, zoom in on the signal frequencies area, 
press on "data cursor" on matlab figure window, than press the point where
a required frequency start, and look on the cursors: the x cursor is the
frequency, the y frequency is the time it starts.